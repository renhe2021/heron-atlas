"""Small HTML tree for static diagnostics, not a JavaScript/CSS renderer."""
from html.parser import HTMLParser
import re

VOID = set('area base br col embed hr img input link meta param source track wbr'.split())
NON_TEXT = {'script', 'style', 'template', 'head'}


class Node:
    def __init__(self, tag='', attrs=(), parent=None):
        self.tag, self.attrs, self.parent = tag, dict(attrs), parent
        self.children = []

    def walk(self):
        for child in self.children:
            if isinstance(child, Node):
                yield child
                yield from child.walk()

    def text(self, visible=False):
        if self.tag in NON_TEXT or (visible and self.hidden()): return ''
        return ' '.join(' '.join(c.text(visible) if isinstance(c,Node) else c for c in self.children).split())

    def hidden(self):
        return 'hidden' in self.attrs or (self.parent is not None and self.parent.hidden())

    def path(self):
        if not self.parent or not self.parent.tag: return self.tag
        siblings=[c for c in self.parent.children if isinstance(c,Node)]
        return self.parent.path()+' > '+self.tag+':nth-child('+str(siblings.index(self)+1)+')'

    def matches(self, selector):
        # Literal selectors found in the deployed script. Unsupported compound
        # combinators remain explicitly listed by analyze_script, not guessed.
        if ',' in selector: return any(self.matches(x.strip()) for x in selector.split(','))
        if re.search(r'[ >+~:]', selector): return False
        tag=re.match(r'^[a-zA-Z][\w-]*',selector)
        if tag and tag[0]!=self.tag: return False
        for cl in re.findall(r'\.([\w-]+)',selector):
            if cl not in self.attrs.get('class','').split(): return False
        for ident in re.findall(r'#([\w-]+)',selector):
            if self.attrs.get('id')!=ident: return False
        for key,_,value in re.findall(r'\[([\w-]+)(?:=([\'"]?)([^\]\'"]+)\2)?\]',selector):
            if key not in self.attrs or (value and self.attrs[key]!=value): return False
        return bool(tag or selector.startswith(('[','.','#')))

    def select(self, selector): return [n for n in self.walk() if n.matches(selector)]


class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root=Node(); self.current=self.root
    def handle_starttag(self,tag,attrs):
        node=Node(tag,attrs,self.current); self.current.children.append(node)
        if tag not in VOID: self.current=node
    def handle_startendtag(self,tag,attrs):
        self.handle_starttag(tag,attrs)
        if tag not in VOID: self.handle_endtag(tag)
    def handle_endtag(self,tag):
        node=self.current
        while node.parent:
            if node.tag==tag:
                self.current=node.parent; break
            node=node.parent
    def handle_data(self,data): self.current.children.append(data)


def parse_html(text):
    p=Parser(); p.feed(text); p.close(); return p.root


def trim(text, limit=160):
    text=' '.join(str(text).split())
    if len(text)<=limit: return text
    return text[:limit]+' … ('+str(len(text)-limit)+' more characters not shown)'


def describe(node, visible=False):
    return {'selector':node.path(), 'tag':node.tag, 'text':trim(node.text(visible)),
            'attributes':{k:('' if v is None else v) for k,v in node.attrs.items() if k.startswith('data-') or k in ('id','class','hidden','datetime')}}


def summarize(doc):
    nodes=list(doc.walk())
    title=next((n for n in nodes if n.tag=='title'),None)
    # title is in head, but its own text is readable.
    heading=[{'level':int(n.tag[1]),'text':n.text(not n.hidden()),'hidden':n.hidden()} for n in nodes if re.fullmatch('h[1-4]',n.tag)]
    groups={'list_items':[], 'cards':[], 'table_rows':[], 'definition_pairs':[]}
    for n in nodes:
        if n.hidden() or n.tag in NON_TEXT: continue
        key=('list_items' if n.tag=='li' else 'table_rows' if n.tag=='tr' else
             'cards' if n.tag=='article' or any('card' in c for c in n.attrs.get('class','').split()) else None)
        if key: groups[key].append(describe(n,visible=True))
        if n.tag=='dt' and n.parent:
            siblings=[c for c in n.parent.children if isinstance(c,Node)]
            following=siblings[siblings.index(n)+1:]; values=[]
            for item in following:
                if item.tag=='dt': break
                if item.tag=='dd': values.append(item.text(True))
            groups['definition_pairs'].append({'text':trim(n.text(True)+': '+'; '.join(values))})
    empty=[]
    for n in nodes:
        if ('empty' in n.attrs.get('class','').split() or
            (n.tag in ('p','li','div','span') and re.search(r'暂无|尚无|没有|暫無|尚無|沒有|\bNo\b.{0,90}\byet\b',n.text(not n.hidden()),re.I))):
            empty.append(dict(describe(n,visible=not n.hidden()),hidden=n.hidden()))
    body=next((n for n in nodes if n.tag=='body'),doc)
    return {'title':title.text() if title else None,
            'description':next((n.attrs.get('content') for n in nodes if n.tag=='meta' and n.attrs.get('name','').lower()=='description'),None),
            'headings':heading,'visible_text':body.text(True),
            'items':{k:{'count':len(v),'items':v} for k,v in groups.items()},
            'empty_states':empty, 'hidden':[describe(n) for n in nodes if 'hidden' in n.attrs]}


def home_rows(doc):
    result=[]
    for n in doc.walk():
        if not any(k in n.attrs for k in ('data-home-candidate','data-economy')): continue
        times=[{k:v for k,v in t.attrs.items() if k=='datetime' or k.startswith('data-')}
               for t in [n,*n.walk()] if any(k in t.attrs for k in ('datetime','data-countdown','data-time','data-at'))]
        headings=[x for x in n.walk() if re.fullmatch('h[1-6]',x.tag)]
        result.append(dict(describe(n),name=headings[0].text() if headings else trim(n.text()),
                           economy=n.attrs.get('data-economy',n.attrs.get('data-home-candidate')),
                           times=times,static_hidden=n.hidden()))
    return result

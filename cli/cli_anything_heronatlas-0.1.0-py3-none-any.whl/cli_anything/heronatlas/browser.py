"""Headless Chrome over NUL-delimited CDP on fd 3/4, standard library only."""
import json
import os
import select
import shutil
import subprocess
import sys
import tempfile
import time
from urllib.parse import urlsplit


class CDPError(RuntimeError): pass


def resource_failures(events, session, page_url, main_frame=None):
    """Join CDP failures to requests, scoped to this navigation/session.

    Keep all resource types. An analytics/image/iframe failure is evidence,
    while a failed main document or local script prevents state acceptance.
    """
    events=[e for e in events if e.get('sessionId')==session]
    requests={}
    for event in events:
        if event.get('method')=='Network.requestWillBeSent':
            p=event.get('params',{})
            requests[p.get('requestId')]={'url':p.get('request',{}).get('url'),
                'resource_type':p.get('type'),'frame_id':p.get('frameId')}
    def origin(url):
        p=urlsplit(url)
        return p.scheme,p.hostname,p.port or (443 if p.scheme=='https' else 80)
    failures=[]
    for event in events:
        method=event.get('method'); p=event.get('params',{})
        if method not in ('Network.loadingFailed','Network.responseReceived'): continue
        response=p.get('response',{})
        if method=='Network.responseReceived' and response.get('status',0)<400: continue
        request=requests.get(p.get('requestId'),{})
        url=response.get('url') or request.get('url')
        kind=p.get('type') or request.get('resource_type') or 'unknown'
        frame=p.get('frameId') or request.get('frame_id')
        reason=('HTTP '+str(response['status']) if method=='Network.responseReceived' else
                p.get('blockedReason') or p.get('errorText') or 'loading failed (reason unavailable)')
        main=kind=='Document' and ((main_frame and frame==main_frame) or
              (not main_frame or not frame) and url==page_url)
        fatal=bool(main or kind=='Script' and url and origin(url)==origin(page_url))
        failures.append({'url':url or '(URL unavailable: no matching requestWillBeSent)',
            'resource_type':kind,'reason':reason,'status':response.get('status'),
            'request_id':p.get('requestId'),'fatal':fatal,'event':event})
    return failures


class PipeCDP:
    def __init__(self, read_fd, write_fd, timeout=20):
        self.read_fd,self.write_fd,self.timeout=read_fd,write_fd,timeout
        self.buffer=b''; self.next_id=0; self.pending={}; self.events=[]

    def call(self, method, params=None, session_id=None):
        self.next_id+=1; ident=self.next_id
        command={'id':ident,'method':method,'params':params or {}}
        if session_id: command['sessionId']=session_id
        raw=json.dumps(command).encode()+b'\0'
        try:
            while raw:
                written=os.write(self.write_fd,raw)
                if not written: raise CDPError('CDP pipe closed while writing '+method)
                raw=raw[written:]
        except OSError as e: raise CDPError('CDP pipe write failed for '+method+': '+str(e)) from e
        deadline=time.monotonic()+self.timeout
        while ident not in self.pending:
            while b'\0' in self.buffer:
                frame,self.buffer=self.buffer.split(b'\0',1)
                if not frame: continue
                try: message=json.loads(frame)
                except (ValueError,UnicodeError) as e: raise CDPError('Invalid CDP JSON frame: '+str(e)) from e
                if not isinstance(message,dict): raise CDPError('CDP frame is not an object')
                if 'id' in message: self.pending[message['id']]=message
                else: self.events.append(message)
            if ident in self.pending: break
            remaining=deadline-time.monotonic()
            if remaining<=0: raise CDPError('CDP timed out waiting for '+method+' id='+str(ident))
            if not select.select([self.read_fd],[],[],remaining)[0]: continue
            chunk=os.read(self.read_fd,65536)
            if not chunk: raise CDPError('CDP pipe closed waiting for '+method)
            self.buffer+=chunk
            if len(self.buffer)>32*1024*1024: raise CDPError('CDP frame exceeds 32 MiB')
        response=self.pending.pop(ident)
        if 'error' in response: raise CDPError(method+': '+json.dumps(response['error'],ensure_ascii=False))
        return response.get('result',{})


def find_chrome(explicit=None):
    if explicit:
        path=shutil.which(explicit) or explicit
        if not os.path.isfile(path) or not os.access(path,os.X_OK): raise RuntimeError('Chrome not found or not executable: '+explicit)
        return path
    for path in ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',shutil.which('google-chrome'),shutil.which('chromium')]:
        if path and os.path.isfile(path) and os.access(path,os.X_OK): return path
    raise RuntimeError('Chrome not found: tried /Applications/Google Chrome.app/Contents/MacOS/Google Chrome, google-chrome, chromium; use --chrome PATH')


# Instruments actual writes before search.js, preserving native behavior. Stacks
# record the executed source locations; no interpretation is substituted for them.
OBSERVER = r"""
window.__haMutations = [];
const pathOf = (n) => { const parts=[]; while(n && n.nodeType===1) {
 const p=n.parentElement; parts.unshift(n.tagName.toLowerCase()+(p?':nth-child('+(Array.from(p.children).indexOf(n)+1)+')':''));n=p;}return parts.join(' > '); };
const record = (n,op,before) => window.__haMutations.push({selector:pathOf(n),op,before,after:n.hasAttribute('hidden'),stack:new Error().stack});
const hiddenDescriptor=Object.getOwnPropertyDescriptor(HTMLElement.prototype,'hidden');
if(hiddenDescriptor && hiddenDescriptor.set) Object.defineProperty(HTMLElement.prototype,'hidden',{
 ...hiddenDescriptor,set(value){const before=this.hasAttribute('hidden');hiddenDescriptor.set.call(this,value);record(this,'hidden property',before);}});
for(const name of ['setAttribute','removeAttribute','toggleAttribute']) {
 const original=Element.prototype[name]; Element.prototype[name]=function(...args){
 const before=this.hasAttribute('hidden');const result=original.apply(this,args);
 if(String(args[0]).toLowerCase()==='hidden')record(this,name,before);return result;};
}
"""

CAPTURE = r"""(selectors) => {
const pathOf = (n) => {const parts=[];while(n && n.nodeType===1){const p=n.parentElement;
 parts.unshift(n.tagName.toLowerCase()+(p?':nth-child('+(Array.from(p.children).indexOf(n)+1)+')':''));n=p;}return parts.join(' > ');};
const visible = n => {for(let p=n;p;p=p.parentElement){const s=getComputedStyle(p);
 if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse'||Number(s.opacity)===0)return false;}
 return n.getClientRects().length>0;};
const text = n => {const w=document.createTreeWalker(n,NodeFilter.SHOW_TEXT);let out=[],t;
 while(t=w.nextNode())if(visible(t.parentElement)&&!['SCRIPT','STYLE','TEMPLATE'].includes(t.parentElement.tagName))out.push(t.textContent);return out.join(' ').replace(/\s+/g,' ').trim();};
const attrs=n=>Object.fromEntries(Array.from(n.attributes).filter(a=>a.name.startsWith('data-')||['datetime','hidden','id','class'].includes(a.name)).map(a=>[a.name,a.value]));
const rows=Array.from(document.querySelectorAll('[data-home-candidate],[data-economy]')).map(n=>({selector:pathOf(n),
 module_heading:n.closest('section')?.querySelector('h1,h2,h3,h4')?.textContent.trim()||'',
 name:n.querySelector('h1,h2,h3,h4,h5,h6')?.textContent.trim()||n.textContent.trim(),text:text(n),
 economy:n.getAttribute('data-economy')||n.getAttribute('data-home-candidate'),attributes:attrs(n),
 times:Array.from(n.querySelectorAll('[datetime],[data-countdown],[data-time],[data-at]')).map(attrs),
 hidden:n.hasAttribute('hidden'),visible:visible(n),mutations:(window.__haMutations||[]).filter(m=>m.selector===pathOf(n))}));
const modules=new Set();const selectorErrors=[];
for(const s of selectors)try{document.querySelectorAll(s).forEach(n=>{const section=n.closest('section');if(section)modules.add(section);});}catch(e){selectorErrors.push({selector:s,error:String(e)});}
return {url:location.href,title:document.title,observed_at:new Date().toISOString(),readyState:document.readyState,
 modules:Array.from(modules).map(n=>({selector:pathOf(n),visible:visible(n),text:text(n),
 heading:n.querySelector('h1,h2,h3,h4')?.textContent.trim()||'',visible_rows:rows.filter(r=>n.contains(document.querySelector(r.selector))&&r.visible).length})),
 follow_rows:Array.from(document.querySelectorAll('[data-follow-economy]')).map(n=>({selector:pathOf(n),
 name:n.labels?.[0]?.textContent.trim()||n.textContent.trim(),economy:n.getAttribute('data-follow-economy'),
 visible:visible(n),checked:typeof n.checked==='boolean'?n.checked:n.getAttribute('aria-pressed')==='true',
 attributes:attrs(n),times:[]})),
 rows,selector_errors:selectorErrors,errors:[]};
}"""


class ChromeBrowser:
    def __init__(self, chrome=None, cdp=None):
        self.cdp=cdp; self.process=None; self.profile=None; self.stderr=None
        if cdp is not None: return
        path=find_chrome(chrome)
        self.profile=tempfile.TemporaryDirectory(prefix='heronatlas-chrome-')
        self.stderr=tempfile.TemporaryFile()
        child_read,parent_write=os.pipe(); parent_read,child_write=os.pipe()
        # A tiny child bootstrap duplicates inherited pipes to Chrome's required
        # fds without preexec_fn (unsafe in threaded Python) or a shell.
        bootstrap='import os,sys,fcntl; a=fcntl.fcntl(int(sys.argv[1]),fcntl.F_DUPFD,10); b=fcntl.fcntl(int(sys.argv[2]),fcntl.F_DUPFD,10); os.dup2(a,3); os.dup2(b,4); os.close(a); os.close(b); os.execv(sys.argv[3],sys.argv[3:])'
        args=[path,'--headless=new','--remote-debugging-pipe','--no-first-run','--no-default-browser-check',
              '--disable-background-networking','--disable-component-update','--disable-sync',
              '--user-data-dir='+self.profile.name,'about:blank']
        try:
            self.process=subprocess.Popen([sys.executable,'-c',bootstrap,str(child_read),str(child_write),*args],
                  pass_fds=(child_read,child_write),stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=self.stderr)
            self.cdp=PipeCDP(parent_read,parent_write)
            self.cdp.call('Browser.getVersion')
        except Exception as e:
            self.stderr.seek(0); detail=self.stderr.read().decode(errors='replace')[-6000:]
            self.close()
            raise CDPError('Chrome startup failed: '+str(e)+'; stderr: '+detail) from e
        finally:
            os.close(child_read); os.close(child_write)

    def evaluate(self, expression, session):
        result=self.cdp.call('Runtime.evaluate',{'expression':expression,'returnByValue':True,'awaitPromise':True},session)
        if 'exceptionDetails' in result: raise CDPError('Browser JavaScript error: '+json.dumps(result['exceptionDetails'],ensure_ascii=False))
        if result.get('result',{}).get('subtype')=='error': raise CDPError('Browser evaluation error: '+str(result['result']))
        return result.get('result',{}).get('value')

    def capture(self, url, storage, analysis):
        contract=analysis['storage']
        if contract.get('error'): raise CDPError('Cannot seed storage: '+contract['error'])
        target=self.cdp.call('Target.createTarget',{'url':'about:blank'})['targetId']
        session=self.cdp.call('Target.attachToTarget',{'targetId':target,'flatten':True})['sessionId']
        try:
            self.cdp.call('Page.enable',session_id=session)
            self.cdp.call('Runtime.enable',session_id=session)
            self.cdp.call('Network.enable',session_id=session)
            seed='window.localStorage.clear();'
            if storage is not None:
                seed+='window.localStorage.setItem('+json.dumps(contract['key'])+',JSON.stringify('+json.dumps(storage)+'));'
            seed='try{'+seed+'}catch(e){window.__haSeedError=String(e);}\n'+OBSERVER
            self.cdp.call('Page.addScriptToEvaluateOnNewDocument',{'source':seed},session)
            start=len(self.cdp.events)
            navigation=self.cdp.call('Page.navigate',{'url':url},session)
            if navigation.get('errorText'): raise CDPError('Page.navigate '+url+': '+navigation['errorText'])
            deadline=time.monotonic()+25
            while True:
                ready=self.evaluate('({ready:document.readyState,url:location.href,seedError:window.__haSeedError})',session)
                if ready and ready.get('url')!='about:blank' and ready.get('ready')=='complete': break
                if time.monotonic()>deadline: raise CDPError('Page load timed out: '+url)
                time.sleep(.05)
            if ready.get('seedError'): raise CDPError('Storage seeding failed: '+ready['seedError'])
            # Static scripts run before load; allow two task turns for handlers.
            selectors=[s for s in analysis['selectors'] if 'home' in s or 'follow' in s or 'economy' in s]
            result=self.evaluate('('+CAPTURE+')('+json.dumps(selectors)+')',session)
            if not isinstance(result,dict): raise CDPError('Browser capture returned no object: '+url)
            events=self.cdp.events[start:]
            result.setdefault('errors',[])
            result['subresource_failures']=resource_failures(events,session,url,navigation.get('frameId'))
            result['runtime_findings']=[]
            for failure in result['subresource_failures']:
                if failure['fatal']:
                    result['errors'].append({'error':failure['resource_type']+' '+failure['reason'],'url':failure['url']})
            for e in events:
                if e.get('sessionId')!=session: continue
                if e.get('method')=='Inspector.targetCrashed': result['errors'].append(e)
                if e.get('method')=='Runtime.exceptionThrown': result['runtime_findings'].append(e)
                p=e.get('params',{})
                if e.get('method')=='Network.responseReceived' and p.get('type')=='Document':
                    if p.get('frameId')==navigation.get('frameId') or p.get('response',{}).get('url')==url:
                        result['http_status']=p['response']['status']
            return result
        finally: self.cdp.call('Target.closeTarget',{'targetId':target})

    def close(self):
        if self.process:
            if self.process.poll() is None:
                self.process.terminate()
                try: self.process.wait(timeout=3)
                except subprocess.TimeoutExpired: self.process.kill(); self.process.wait(timeout=3)
            self.process=None
        if self.cdp and isinstance(self.cdp,PipeCDP):
            for fd in (self.cdp.read_fd,self.cdp.write_fd):
                try: os.close(fd)
                except OSError: pass
            self.cdp=None
        if self.stderr: self.stderr.close(); self.stderr=None
        if self.profile is not None: self.profile.cleanup(); self.profile=None

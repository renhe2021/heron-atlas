"""Small, strict public JSON reader. Never scrapes HTML or consults private data."""
import json
import re
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit, urlunsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
import click

API_VERSION = 1
TIMEOUT = 15
USER_AGENT = 'cli-anything-heronatlas/0.1.0'
API_ROOT = 'api/v1/'
# Explicit diagnostic probe only; no server is started by the reader.
CLOSED_LOOPBACK_BASE = 'http://127.0.0.1:1'


def base_url(value):
    try:
        parts = urlsplit(value)
        port = parts.port
        if (parts.scheme not in ('https', 'http') or not parts.hostname or parts.username is not None
                or parts.password is not None or parts.query or parts.fragment or '\\' in value
                or re.search(r'\s|[\x00-\x1f\x7f%]', value)
                or any(p in ('.', '..') for p in parts.path.split('/'))
                or (parts.scheme == 'http' and parts.hostname != '127.0.0.1')):
            raise ValueError()
    except (ValueError, TypeError):
        raise click.BadParameter('base URL must use HTTPS (HTTP only for 127.0.0.1 tests), without credentials, query, fragment or traversal') from None
    return urlunsplit((parts.scheme, parts.netloc, parts.path.rstrip('/') + '/', '', ''))


class NoRedirect(HTTPRedirectHandler):
    # Redirects can cross origins or downgrade HTTPS; explicit failure is preferable.
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Client:
    def __init__(self, base):
        self.base = base_url(base)
        self.index = self.get('api/v1/index.json')
        if type(self.index.get('schema_version')) is not int or self.index['schema_version'] != API_VERSION:
            raise click.ClickException('Unsupported schema version; this CLI requires api/v1 schema_version=1')
        if not isinstance(self.index.get('built_at'), str) or not isinstance(self.index.get('endpoints'), list):
            raise click.ClickException('Malformed API index: missing built_at or endpoints')
        for i, endpoint in enumerate(self.index['endpoints']):
            problem=None
            if not isinstance(endpoint,dict): problem='expected an object'
            else:
                for field in ('path','description','language','format'):
                    if not isinstance(endpoint.get(field),str) or not endpoint[field].strip():
                        problem=field+' must be a non-empty string'; break
                if problem is None and ('checked_at' not in endpoint or (endpoint['checked_at'] is not None and not isinstance(endpoint['checked_at'],str))):
                    problem='checked_at must be a string or null'
                if problem is None and endpoint['language'] not in ('zh','zh-hant','en','all'):
                    problem='language must be zh, zh-hant, en or all'
            if problem:
                raise click.ClickException('Malformed API index: endpoints['+str(i)+']: '+problem)

    def get(self, path):
        url = self.base + path
        try:
            opener = build_opener(NoRedirect)
            with opener.open(Request(url, headers={'User-Agent': USER_AGENT, 'Accept': 'application/json'}), timeout=TIMEOUT) as response:
                data = json.loads(response.read().decode('utf-8'), parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))
        except HTTPError as exc:
            raise click.ClickException('HTTP ' + str(exc.code) + ': ' + url) from None
        except (URLError, TimeoutError, OSError) as exc:
            raise click.ClickException('Network error for ' + url + ': ' + str(exc.reason if isinstance(exc, URLError) else exc)) from None
        except (ValueError, UnicodeError):
            raise click.ClickException('Invalid JSON from ' + url) from None
        if not isinstance(data, dict):
            raise click.ClickException('Expected a JSON object from ' + url)
        return data

    def read(self, name, lang='zh'):
        prefix = '' if lang == 'zh' else lang + '/'
        path = 'api/v1/' + prefix + name + '.json'
        endpoint = next((e for e in self.index['endpoints'] if e.get('path') == path), None)
        if endpoint is None:
            if lang == 'en':
                raise click.ClickException('English data is not available for ' + name + '; no admitted English fields')
            raise click.ClickException('Unknown endpoint: ' + path)
        data = self.get(path)
        if name == 'judgments':
            version = data.get('format')
        else:
            version = data.get('schema_version')
        if type(version) is not int or version != API_VERSION:
            raise click.ClickException('Unsupported schema version at ' + path)
        return data, self.base + path

    def annotate(self, data, source_url, fallback=None):
        # Keep all parsed fields; only add provenance. A null checked date stays unknown.
        as_of = data.get('checked_at', data.get('approved_at', fallback or self.index['built_at']))
        return dict(data, source_url=source_url, as_of=as_of)

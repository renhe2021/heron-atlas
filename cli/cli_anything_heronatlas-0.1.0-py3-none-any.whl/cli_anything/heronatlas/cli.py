"""Click commands and a small shlex REPL; the only backend is the public JSON API."""
from datetime import date, datetime, timedelta, timezone
import json
import shlex
import unicodedata
from urllib.parse import urlsplit, urljoin
import click
from .client import Client, base_url

STATUS = {'有效':'Open','兑现':'Correct','落空':'Wrong','撤回':'Withdrawn'}
# Mirror public_site_phase2.ECONOMIES without depending on the private backend.
# A parity regression keeps this standalone wheel's public codes aligned.
ECONOMIES = ('us', 'ea', 'jp', 'uk', 'cn', 'ca', 'au', 'ch', 'se')


def table(rows, columns):
    def cell(value):
        if value is None: return '—'
        if isinstance(value, (dict, list)): return json.dumps(value, ensure_ascii=False, sort_keys=True)
        return str(value).replace('\n', ' ')
    values = [[cell(row.get(k)) for k in columns] for row in rows]
    width=lambda text:sum(0 if unicodedata.combining(c) else 2 if unicodedata.east_asian_width(c) in ('W','F') else 1 for c in text)
    widths = [max([width(k)] + [width(r[i]) for r in values]) for i,k in enumerate(columns)]
    render = lambda row:'  '.join(s+' '*(w-width(s)) for s,w in zip(row,widths)).rstrip()
    return '\n'.join([render(columns), render(['-'*w for w in widths])] + [render(row) for row in values])


def emit(data, as_json, columns=None):
    if as_json:
        click.echo(json.dumps(data, ensure_ascii=False, sort_keys=True, allow_nan=False))
    elif isinstance(data, list):
        click.echo(table(data, columns or (list(data[0]) if data else ['id'])))
        if not data: click.echo('(empty)')
    elif 'citation' in data:
        click.echo(data['citation'])
    elif 'ops' in data:
        click.echo(table([data], ['date','previous_date','decision','vote']))
        sentences=[]
        for op in data['ops']:
            languages=sorted(set((op['old'] or {}).keys()) | set((op['new'] or {}).keys()))
            for language in languages:
                sentences.append({'op':op['op']+'/'+language,'before':(op['old'] or {}).get(language),'after':(op['new'] or {}).get(language)})
        click.echo(table(sentences,['op','before','after']))
        click.echo('Source: '+data['source_url']+'; as of '+str(data['as_of']))
    elif 'endpoints' in data:
        click.echo('Heron Atlas; built_at '+data['built_at'])
        click.echo(table(data['endpoints'],['path','language','checked_at']))
    else:
        click.echo(table([{'field':k,'value':v} for k,v in data.items()], ['field','value']))


def output_options(fn):
    fn = click.option('--lang',type=click.Choice(['zh','zh-hant','en']),default='zh',show_default=True)(fn)
    fn = click.option('--json','as_json',is_flag=True,help='Print parsed data with source_url and as_of.')(fn)
    return fn


def client():
    ctx=click.get_current_context().find_root()
    if 'client' not in ctx.obj: ctx.obj['client']=Client(ctx.obj['base'])
    return ctx.obj['client']


def rows(name,key,lang):
    c=client(); data,url=c.read(name,lang)
    if not isinstance(data.get(key),list) or any(not isinstance(r,dict) for r in data[key]):
        raise click.ClickException('Malformed data: expected object list '+key)
    return [c.annotate(row,url,data.get('checked_at',data.get('built_at'))) for row in data[key]]


def select(data,key,ident):
    found=next((row for row in data if row.get(key)==ident),None)
    if found is None: raise click.ClickException('Unknown '+key+': '+ident)
    return found


def identifier(value):
    import re
    if not re.fullmatch(r'[a-z0-9][a-z0-9-]*',value):
        raise click.BadParameter('Use a lowercase bank id or event slug')
    return value


def day_option(ctx,param,value):
    if value is not None:
        try:
            if date.fromisoformat(value).isoformat()!=value: raise ValueError()
        except ValueError: raise click.BadParameter('Use YYYY-MM-DD') from None
    return value


@click.group(invoke_without_command=True)
@click.option('--base-url',envvar='HERON_ATLAS_BASE_URL',default='https://heronatlas.com',show_default=True)
@click.pass_context
def main(ctx,base_url):
    """Read Heron Atlas public research. No command starts the interactive REPL."""
    from .client import base_url as validate
    ctx.ensure_object(dict); ctx.obj['base']=validate(base_url)
    if ctx.invoked_subcommand is None:
        click.echo('Heron Atlas REPL — help for commands; exit to leave.')
        while True:
            try: line=click.prompt('heronatlas',prompt_suffix='> ')
            except (EOFError,click.Abort): break
            if line.strip() in ('exit','quit'): break
            if not line.strip(): continue
            try:
                args=shlex.split(line)
                if args==['help']: args=['--help']
                main.main(['--base-url',ctx.obj['base'],*args],standalone_mode=False)
            except (click.ClickException,ValueError) as exc:
                if isinstance(exc,click.ClickException): exc.show()
                else: click.echo('Error: '+str(exc),err=True)
            except SystemExit:
                pass


@main.command()
@output_options
def info(as_json,lang):
    """API endpoints, build time and source freshness."""
    c=client(); emit(c.annotate(c.index,c.base+'api/v1/index.json'),as_json)


@main.command()
@output_options
def banks(as_json,lang):
    """Verified policy-rate table; null rates stay unknown."""
    emit(rows('central-banks','banks',lang),as_json,['id','name','rate','checked_at','schedule_url'])


def pairs(bank,lang):
    return rows('statements/'+identifier(bank),'pairs',lang)


@main.command()
@click.argument('bank')
@output_options
def statements(bank,as_json,lang):
    """List admitted adjacent decision pairs, newest first."""
    emit(pairs(bank,lang),as_json,['date','previous_date','decision','page_url'])


@main.command()
@click.argument('bank')
@click.option('--date','day',callback=day_option,help='Decision date YYYY-MM-DD; default latest pair.')
@output_options
def statement(bank,day,as_json,lang):
    """Sentence changes and decision/vote for one decision pair."""
    data=pairs(bank,lang)
    if not data: raise click.ClickException('No admitted statement pairs for '+bank)
    emit(select(data,'date',day) if day else data[0],as_json)


@main.command()
@output_options
def events(as_json,lang):
    """Approved editorial event pages."""
    emit(rows('events','events',lang),as_json,['slug','date','title','agency','page_url'])


@main.command()
@click.argument('slug')
@output_options
def event(slug,as_json,lang):
    """Read an approved event, including published results."""
    emit(select(rows('events','events',lang),'slug',identifier(slug)),as_json)


def instant(value):
    try:
        stamp=datetime.fromisoformat(value.replace('Z','+00:00'))
        if stamp.tzinfo is None: raise ValueError()
        return stamp
    except (ValueError,TypeError,AttributeError):
        raise click.ClickException('Malformed timezone-aware date in public data') from None


@main.command()
@click.option('--status',type=click.Choice(list(STATUS)))
@click.option('--due-within',type=click.IntRange(min=0),help='Due from UTC now through N days, inclusive.')
@output_options
def judgments(status,due_within,as_json,lang):
    """Read the public judgment ledger; optional status/due-date filters."""
    data=rows('judgments','judgments',lang)
    if status:
        wanted=STATUS[status] if lang=='en' else status
        if lang=='zh-hant':
            wanted={'有效':'有效','兑现':'兌現','落空':'落空','撤回':'撤回'}[status]
        data=[r for r in data if r.get('status')==wanted]
    if due_within is not None:
        now=datetime.now(timezone.utc); until=now+timedelta(days=due_within)
        data=[r for r in data if now<=instant(r['check']['at'])<=until]
    emit(data,as_json,['id','status','statement_en' if lang=='en' else 'statement','check'])


@main.command()
@click.argument('id')
@output_options
def judgment(id,as_json,lang):
    """Read one signed judgment by stable id."""
    emit(select(rows('judgments','judgments',lang),'id',id),as_json)


@main.command()
@click.option('--economy',metavar='CODE',help='Filter by a site economy code or any code present in the calendar API.')
@click.option('--days',type=click.IntRange(min=0),help='UTC now through N days; date-only entries remain dates.')
@output_options
def calendar(economy,days,as_json,lang):
    """Read the key-event calendar behind the site's ICS subscriptions."""
    data=rows('calendar','entries',lang)
    now=datetime.now(timezone.utc)
    if economy is not None:
        # A current snapshot may omit a supported economy entirely. Data can
        # extend the site's public codes, but cannot shrink the allowed set.
        economy = economy.lower()
        choices = sorted(set(ECONOMIES) | {r['economy'].lower() for r in data})
        ctx = click.get_current_context()
        param = next(p for p in ctx.command.params if p.name == 'economy')
        economy = click.Choice(choices).convert(economy, param, ctx)
        data=[r for r in data if r['economy'].lower()==economy]
    def upcoming(row):
        if row['date_only']:
            at=date.fromisoformat(row['scheduled_at'])
            return at>=now.date() and (days is None or at<=now.date()+timedelta(days=days))
        at=instant(row['scheduled_at'])
        return at>=now and (days is None or at<=now+timedelta(days=days))
    data=[r for r in data if upcoming(r)]
    if not data and not as_json:
        click.echo('No events.')
    else:
        emit(data,as_json,['scheduled_at','economy','title','official_url'])


@main.command()
@click.argument('url_or_path')
@output_options
def cite(url_or_path,as_json,lang):
    """Cite a public page with its checked date (unknown remains unknown)."""
    c=client(); target=urljoin(c.base,url_or_path)
    p,b=urlsplit(target),urlsplit(c.base)
    if (p.scheme,p.netloc)!=(b.scheme,b.netloc) or not p.path.startswith(b.path) or p.query:
        raise click.BadParameter('Citation URL must be a page or endpoint under the base URL')
    path=p.path[len(b.path):].removesuffix('index.html').strip('/')
    page_lang=lang
    for language in ('en','zh-hant'):
        if path.startswith(language+'/'): page_lang=language; path=path[len(language)+1:]
    prefix='' if page_lang=='zh' else page_lang+'/'
    # Latest statement addresses cite their immutable pair page.
    if path.startswith('central-banks/'):
        parts=path.split('/')
        if len(parts) not in (2,3): raise click.ClickException('Unknown public citation path: '+path)
        data,_=c.read('statements/'+identifier(parts[1]),page_lang)
        if not data['pairs']: raise click.ClickException('No admitted statement pairs for '+parts[1])
        pair=select(data['pairs'],'date',parts[2]) if len(parts)==3 else data['pairs'][0]
        path='central-banks/'+parts[1]+'/'+pair['date']
    page=next((r for r in c.index.get('pages',[]) if r['path']==prefix+path),None)
    endpoint=next((r for r in c.index['endpoints'] if r['path']==path),None)
    if page is not None:
        checked=page['checked_at']
        target=c.base+prefix+path+('/' if path and not path.endswith('.html') else '')
        if p.fragment:
            if path=='judgments': select(rows('judgments','judgments',page_lang),'id',p.fragment)
            target+='#'+p.fragment
    elif endpoint is not None:
        checked=endpoint.get('checked_at')
        target=c.base+path
    else:
        raise click.ClickException('Unknown public citation path: '+prefix+path)
    if checked:
        # Site checked timestamps are cited by Beijing date, matching the public pages.
        checked=checked if len(checked)==10 else instant(checked).astimezone(timezone(timedelta(hours=8))).date().isoformat()
    citation='Source: Heron Atlas, '+target+', as of '+(checked or 'unknown')
    emit({'citation':citation,'source_url':target,'as_of':checked},as_json)


@main.command('debug-snapshot')
@click.option('--format','format_',type=click.Choice(['markdown','json']),default='markdown',show_default=True)
@click.option('--out',type=click.Path(dir_okay=False,writable=True),help='Write report here, including partial/error reports.')
@click.option('--site-url',default='https://heronatlas.com',show_default=True)
@click.option('--cli-base-url',default=None,help='CLI test base URL; defaults to --site-url.')
@click.option('--sections',default='1,2,3,4',show_default=True,help='Comma-separated section numbers 1–4.')
@click.option('--max-items',type=click.IntRange(min=1),default=8,show_default=True,help='Presentation cap per list; JSON retains all records.')
@click.option('--no-external',is_flag=True,help='Skip external official-source reachability checks.')
@click.option('--chrome',type=click.Path(),help='Headless Chrome executable (CDP pipe, no websocket).')
def debug_snapshot(format_,out,site_url,cli_base_url,sections,max_items,no_external,chrome):
    """Fetch a factual product walkthrough, simulate browser states, and exercise CLI UX."""
    from . import snapshot
    try:
        values=list(dict.fromkeys(int(s.strip()) for s in sections.split(',')))
        if not values or any(s not in (1,2,3,4) for s in values): raise ValueError()
    except ValueError: raise click.BadParameter('Use comma-separated section numbers 1,2,3,4',param_hint='--sections') from None
    data=snapshot.collect(site_url,cli_base_url,sections=values,max_items=max_items,no_external=no_external,chrome=chrome)
    report=snapshot.render(data,format_,max_items)
    if out:
        with open(out,'w',encoding='utf-8') as f: f.write(report)
    else: click.echo(report,nl=False)
    if data['errors']: raise click.ClickException('Snapshot incomplete: '+'; '.join(data['errors']))

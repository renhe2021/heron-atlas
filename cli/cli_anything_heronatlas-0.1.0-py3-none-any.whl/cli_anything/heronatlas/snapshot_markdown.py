"""Reader-oriented projection of snapshot evidence; JSON remains the full record.

Every block owns a byte allowance. Pages, state tables and command samples have
independent shares, so a verbose early receipt cannot erase a later page/table.
"""
from collections import Counter
import json
import re
from urllib.parse import urlsplit

LIMITS = {'header': 6000, '1': 40000, '2': 18000, '3': 16000, '4': 14000}
NAMES = {'1': 'Route and subpage inventory',
         '2': 'Interactive state simulation — 我的关注 / 下一件要紧事',
         '3': 'Data and link integrity', '4': 'CLI UX self-test'}


def size(text): return len(text.encode('utf-8'))


def text(value, limit=240):
    if value is None: return 'unavailable'
    value=' '.join(str(value).split()).replace('`', "'")
    # Never emit a raw JSON object (including JSON CLI output/errors) in prose.
    if re.search(r'\{\s*"[^"\n]+"\s*:', value):
        return 'Structured receipt retained in JSON'
    return value if len(value)<=limit else value[:max(0,limit-1)]+'…'


def cell(value, limit=240):
    return text(value,limit).replace('|','\\|').replace('<','&lt;').replace('>','&gt;')


def short_bytes(value, budget):
    value=str(value)
    if size(value)<=budget: return value
    return value.encode()[:max(0,budget-3)].decode('utf-8',errors='ignore')+'…'


def omitted(n): return str(n)+' more not shown (full evidence in JSON)'


def lines_block(lines, budget):
    """Cap whole lines, reserving a truthful omitted-line count."""
    if size('\n'.join(lines)+'\n')<=budget: return '\n'.join(lines)+'\n'
    keep=[]; used=0
    for line in lines:
        if used+size(line+'\n')+size(omitted(len(lines))+'\n')>budget: break
        keep.append(line); used+=size(line+'\n')
    return '\n'.join(keep+[omitted(len(lines)-len(keep))])+'\n'


def item_block(label, lines, total, budget, cap):
    """Apply item and byte limits once, retaining the uncapped item total."""
    prefix=label+'\n\n'; keep=[]; used=size(prefix)
    for line in lines[:cap]:
        remaining=total-len(keep)-1
        notice=size(omitted(remaining)+'\n') if remaining else 0
        if used+size(line+'\n')+notice>budget: break
        keep.append(line); used+=size(line+'\n')
    if len(keep)<total: keep.append(omitted(total-len(keep)))
    if not total: keep.append('- None observed.')
    return prefix+'\n'.join(keep)+'\n'


def bullets(label, values, budget, cap, formatter=lambda v: text(v)):
    return item_block(label,['- '+formatter(v) for v in values[:cap]],len(values),budget,cap)


def table(headers, rows, budget, cap=None):
    # Budget at row boundaries, never half a table row; item caps per table.
    start=['| '+' | '.join(headers)+' |','|'+'|'.join('---' for _ in headers)+'|']
    selected=rows if cap is None else rows[:cap]
    rendered=['| '+' | '.join(cell(c) for c in row)+' |' for row in selected]
    keep=[]; used=size('\n'.join(start)+'\n')
    for row in rendered:
        if used+size(row+'\n')+80>budget: break
        keep.append(row); used+=size(row+'\n')
    remainder=len(rows)-len(keep)
    if remainder: keep.append(omitted(remainder))
    if not rows: keep.append('None observed.')
    return '\n'.join(start+keep)+'\n'


def code_block(lines, budget, language='text', cap=None):
    lines=list(lines)
    # The omission notice counts toward the sample's line cap too.
    selected=lines if cap is None else lines[:cap-1 if len(lines)>cap else cap]
    keep=[]; used=size('```'+language+'\n```\n')
    for line in selected:
        line=line.replace('```', "'''")
        if used+size(line+'\n')+80>budget: break
        keep.append(line);used+=size(line+'\n')
    if len(lines)>len(keep): keep.append(omitted(len(lines)-len(keep)))
    return '```'+language+'\n'+'\n'.join(keep)+'\n```\n'


def path(url): return urlsplit(url).path or '/'


def row_name(row):
    from .snapshot import row_time
    stamp=row_time(row)
    time=stamp.strftime('%m-%d %H:%M UTC') if stamp else 'time unknown'
    return text(row.get('name', row.get('text','Unnamed row')),90)+' '+time


def summary(data):
    """At most 25 lines including whitespace; categories aggregate actual evidence."""
    sections=data['sections']; items=[]
    def add(message, section): items.append('- '+short_bytes(text(message,440),230)+' [Evidence](#section-'+section+').')
    s1=sections.get('1');s2=sections.get('2');s3=sections.get('3')
    if data.get('errors'): add(str(len(data['errors']))+' incomplete-check errors; see section details and JSON.',next(iter(sections),'1'))
    if s1:
        pages=s1.get('pages',[]);other=s1.get('other_sitemap_urls',[])
        bad=[p for p in pages+other if p.get('status')!=200]
        if bad: add(str(len(bad))+' non-200 page responses: '+', '.join(path(p['url']) for p in bad[:3]),'1')
        empty=[p for p in pages if any(not r.get('hidden') for r in p.get('empty_states',[]))]
        if empty: add(str(len(empty))+' pages contain visible empty states: '+', '.join(path(p['url']) for p in empty[:3]),'1')
    if s3:
        broken=[r for r in s3['judgment_links'] if r['status']=='broken']
        if broken: add(str(len(broken))+' broken judgment links: '+', '.join(r['url'] for r in broken[:2]),'3')
        flags=[r for r in s3['calendar_files'] if r.get('flags')]
        if flags: add(str(len(flags))+' ICS label/file discrepancies or uncheckable promises: '+', '.join(path(r['url']) for r in flags[:2]),'3')
        checks=s3['external']['checks'];bad=[r for r in checks if r['classification']!='ok']
        if bad: add(str(len(bad))+' non-ok official links: '+', '.join(r['url'] for r in bad[:2]),'3')
    if s2:
        for flag,label in [('hidden_next_72h','events in the next 72 hours hidden in every state'),('never_revealed','rows hidden in static HTML and never revealed'),('unsupported_economy','rows with unsupported economies'),('heading_count_mismatches','heading/visible-row count mismatches')]:
            rows=[(p,r) for p in s2['pages'] for r in p['flags'].get(flag,[])]
            if rows:
                names=[text(r.get('name',r.get('heading','')),80) for _,r in rows[:3]]
                add(str(len(rows))+' '+label+' (page observations): '+', '.join(names),'2')
        resources=s2.get('subresource_findings',[])
        csp=[r for r in resources if r['reason']=='csp']
        if csp: add(str(len(csp))+' CSP-blocked URLs: '+', '.join(r['url'] for r in csp[:3]),'2')
        others=[r for r in resources if r['reason']!='csp']
        if others: add(str(len(others))+' other failed subresources: '+', '.join(r['url'] for r in others[:2]),'2')
    if not items: items=['- No findings computed in the requested checks.']
    return '## Findings summary\n\n'+lines_block(items[:20],3000)+'\n'


def header(data):
    h=data['header']; lines=['# Heron Atlas diagnostic snapshot','']
    for key,label in [('run_at_utc','Run UTC'),('site_url','Site'),('cli_base_url','CLI base'),('cli_version','CLI version')]:
        lines.append('- '+label+': '+text(h.get(key),240))
    if h.get('built_at'):
        lines.append('- build stamp: '+text(h['built_at'])+' (manifest.json built_at)')
    elif h.get('manifest',{}).get('status')==404:
        lines.append('- build stamp: unavailable (manifest.json not deployed, HTTP 404)')
    else: lines.append('- build stamp: unavailable ('+text(h.get('build_stamp_error','no manifest built_at'),200)+')')
    stamp=h.get('content_timestamp')
    lines.append('- Content timestamp: '+(text(stamp['value'])+'; source: '+cell(stamp['source']) if stamp else 'unavailable; no parseable feed/sitemap timestamps'))
    for key in ('homepage_sha256','search_js_sha256'): lines.append('- '+key+': '+text(h.get(key)))
    lines+=['','Static HTML and browser observations are distinct. JSON retains all collected evidence. Markdown caps are per section, page and table. Findings do not imply a failed snapshot.','']
    return lines_block(lines,2600)+'\n'+summary(data)


def page_block(p, budget, cap):
    status=text('HTTP '+str(p.get('status'))+'; title: '+text(p.get('title'),70)+'; description: '+text(p.get('description'),85),160)
    top='### '+path(p['url'])+'\n\n'+status+'\n'
    if p.get('final_url')!=p['url']: top+='Final URL: '+text(p.get('final_url'),160)+'\n'
    if p.get('error'): top+='Fetch error: '+text(p['error'],120)+'\n'
    headings=p.get('headings',[])
    # Dedupe nested card/list representations while retaining their JSON groups.
    items=[];seen=set()
    for group in p.get('items',{}).values():
        for item in group.get('items',[]):
            value=item.get('text','')
            if value and value not in seen: seen.add(value);items.append(value)
    if not items and p.get('visible_text'): items=[p['visible_text']]
    share=max(100,(budget-size(top)-20)//4)
    heading_lines=['  '*max(0,h['level']-1)+'- h'+str(h['level'])+' '+text(h['text'],120)+(' (hidden)' if h.get('hidden') else '') for h in headings[:min(cap,24)]]
    chunks=[item_block('Heading outline:',heading_lines,len(headings),share,min(cap,24)),
            bullets('Visible items ('+str(len(items))+'):',items,share,min(cap,12),lambda v:text(v,140)),
            bullets('Empty states:',p.get('empty_states',[]),share,min(cap,12),lambda r:text(r['text'],140)+(' (hidden in static HTML)' if r.get('hidden') else '')),
            bullets('hidden in static HTML:',p.get('hidden',[]),share,min(cap,12),lambda r:text(r['text'],100)+
                ('; '+', '.join(k for k in r.get('attributes',{}) if k.startswith('data-')) if any(k.startswith('data-') for k in r.get('attributes',{})) else ''))]
    return top+'\n'.join(chunks)+'\n'


def section1(s,cap):
    pages=s['pages']
    # Always show required roots. Absent optional language variants stay in JSON.
    roots=['/','/zh-hant/','/en/','/central-banks/','/calendar/','/news/','/judgments/','/method/','/rules/','/corrections/','/sources/']
    order={p:i for i,p in enumerate(roots)}
    pages=sorted([p for p in pages if path(p['url']) in roots or p['status']!=404],key=lambda p:order.get(path(p['url']),len(roots)))
    out=text(s['scope'],400)+'\n\n'
    share=34000//max(1,len(pages))
    out+=''.join(page_block(p,share,cap) for p in pages)
    inv=s.get('sitemap_inventory',{k:{'count':v,'non_200':'unknown'} for k,v in s.get('counts_per_top_level_path',{}).items()})
    out+='### Sitemap inventory\n\n'+table(['Path prefix','Count','Non-200'],[(k,v['count'],v['non_200']) for k,v in sorted(inv.items())],1800)
    eligible=set(s.get('sitemap_urls',[]))
    records=s.get('other_sitemap_urls',[])+[dict(p,h1=[h['text'] for h in p.get('headings',[]) if h['level']==1]) for p in s['pages'] if p['url'] in eligible]
    exceptions=[r for r in records if r['status']!=200 or not r.get('title') or not r.get('h1')]
    out+='\nSitemap exceptions (non-200, missing title or missing h1):\n\n'
    out+=table(['URL','HTTP','Issue'],[(r['url'],r['status'],', '.join(msg for ok,msg in [(r['status']==200,'non-200'),(bool(r.get('title')),'missing title'),(bool(r.get('h1')),'missing h1')] if not ok)) for r in exceptions],3500,cap)
    return out


def flag_sentences(p, budget):
    flags=p['flags'];out=[]; groups=[]
    for key,label in [('hidden_next_72h','Hidden within next 72 hours'),('unsupported_economy','Unsupported economies'),('never_revealed','Never revealed'),('heading_count_mismatches','Count mismatches'),('not_checked','Incomplete row checks')]:
        rows=flags.get(key,[])
        out=[label+': '+str(len(rows))+'.']
        for r in rows:
            if key=='hidden_next_72h': sentence=row_name(r)+': hidden in every successfully observed state within the next 72 hours.'
            elif key=='unsupported_economy': sentence=row_name(r)+': economy '+str(r.get('economy'))+' is not offered as a follow option.'
            elif key=='never_revealed': sentence=row_name(r)+': hidden in static HTML; never revealed in the requested states.'
            elif key=='heading_count_mismatches': sentence=text(r['heading'],90)+' in state '+str(r['state'])+': heading count '+str(r['heading_count'])+'; visible rows '+str(r['visible_rows'])+'.'
            else: sentence=row_name(r)+': '+text(r.get('reason'),180)+'.'
            out.append('- '+sentence)
        groups.append(lines_block(out,budget//6))
    out=[]
    # Explain the state(s) that actually reveal each static-hidden event.
    for row in p.get('static_rows',[]):
        if not row.get('static_hidden'): continue
        revealed=[st['state'] for st in p['states'] if not st.get('error') and not st.get('errors') and any(r.get('selector')==row['selector'] and r.get('visible') for r in st.get('rows',[]))]
        if revealed: out.append('- '+row_name(row)+': hidden in static HTML; revealed only in state(s) '+', '.join(revealed)+'.')
    groups.append(lines_block(out,budget//6) if out else '')
    return ''.join(groups)


def source_lines(analysis):
    selectors=sorted(analysis.get('selectors',[]),key=len,reverse=True)
    for row in analysis.get('code',[]):
        line=row['code']
        for selector in selectors:
            # Explicitly marked omission, not a fabricated verbatim quote.
            line=line.replace("'"+selector+"'", "'<selector omitted>'").replace('"'+selector+'"', '"<selector omitted>"')
        line=re.sub(r"((?:querySelectorAll|querySelector|closest|matches)\(\s*)(['\"])(.*?)\2",lambda m:m[1]+m[2]+'<selector omitted>'+m[2],line)
        yield 'L'+str(row['line'])+': '+line


def state_block(p,state,budget,cap):
    from .snapshot import row_time
    top='#### State '+state['state']+'\n\n'
    if state.get('error'): return top+'Could not run: '+text(state['error'],300)+'\n'
    if state.get('errors'):
        top+='State incomplete: '+str(len(state['errors']))+' blocking errors (full receipts in JSON).\n'
    top+='Seed: '+(', '.join(state['seed']) if state.get('seed') is not None else 'empty storage; script default applies')+'.\n'
    top+='Browser UTC: '+text(state.get('observed_at'),40)+'; HTTP '+str(state.get('http_status','unavailable'))+'.\n\n'
    rows=[]
    observed=state.get('rows',[])+state.get('follow_rows',[])
    for row in observed:
        stamp=row_time(row)
        from datetime import timedelta
        beijing=(stamp+timedelta(hours=8)).strftime('%m-%d %H:%M') if stamp else 'unknown'
        utc=stamp.strftime('%m-%d %H:%M') if stamp else 'unknown'
        original=next((r for r in p.get('static_rows',[])+p.get('static_follow_rows',[]) if r['selector']==row.get('selector')),None)
        follow=row in state.get('follow_rows',[])
        module='我的关注' if follow else row.get('module_heading') or '下一件要紧事'
        label=text(row.get('name',row.get('text')),75)+(' (selected)' if row.get('checked') else '')
        rows.append((text(module,35),label,row.get('economy'),beijing,utc,
            'yes' if original and original.get('static_hidden') else 'no' if original else 'unknown',
            'yes' if row.get('visible') else 'no'))
    for module in ([] if state.get('follow_rows') else state.get('modules',[])):
        heading=module.get('heading','')
        if re.search(r'我的关注|我的關注|my follow|following',heading,re.I):
            rows.insert(0,('我的关注',text(module.get('text'),90),'—','—','—','—','yes' if module.get('visible') else 'no'))
    if not any(r[0]=='我的关注' for r in rows): rows.insert(0,('我的关注','No module rows observed','—','—','—','unknown','unknown'))
    follows=[r for r in rows if r[0]=='我的关注']; next_rows=[r for r in rows if r[0]!='我的关注']
    rows=next_rows[:1]+follows[:1]+next_rows[1:]+follows[1:]
    top+=table(['Module','Label','Economy','Beijing','UTC','Static hidden?','Visible after JS?'],rows,max(350,budget-size(top)-15),cap)
    return top+'\n'


def section2(s,cap):
    storage=s['analysis']['storage']
    out='### Storage contract\n\n'+table(['Property','Observed value'],[(k,', '.join(v) if isinstance(v,list) else v) for k,v in storage.items()],1200)
    out+='\n### Source quotations — search.js\n\nSelector literals are omitted from these excerpts; exact source lines and selector identities remain in JSON.\n\n'
    out+=code_block(source_lines(s['analysis']),3300,'javascript')
    if s.get('startup_error'): out+='\nChrome startup error: '+text(s['startup_error'],400)+'\n'
    pages=s.get('pages',[])
    for p in pages:
        out+='\n### '+path(p['url'])+'\n\nFollow options: '+', '.join(p['follow_options'])+'.\n\n'
        share=6000//max(1,len(pages))//max(1,len(p['states']))
        for state in p['states']: out+=state_block(p,state,share,cap)
        out+='Computed flags:\n\n'+flag_sentences(p,4300//max(1,len(pages)))
    out+='\n### Failed or blocked subresources\n\n'
    failures=s.get('subresource_findings',[])
    out+=table(['URL','Type','Reason','States'],[(r['url'],r['resource_type'],r['reason'],', '.join(path(v.rsplit(' ',1)[0])+' '+v.rsplit(' ',1)[-1] for v in r['states'])) for r in failures],1900)
    out+='\n'+text(s.get('scope',''),400)+'\n'
    return out


def section3(s,cap):
    judgments=s['judgment_links'];counts=Counter(r['status'] for r in judgments)
    out='### Judgment links\n\nTotals: '+str(counts['ok'])+' ok; '+str(counts['broken'])+' broken; '+str(counts['not-checked'])+' not checked.\n\n'
    out+=table(['Broken URL','Source page','Target HTTP'],[(r['url'],path(r['source_page']),r.get('target_http')) for r in judgments if r['status']=='broken'],1800,cap)
    files=s['calendar_files']
    out+='\n### ICS files\n\n'+str(len(files))+' linked file occurrences (labels checked separately).\n\n'
    out+=table(['File','Events','Earliest','Latest','Past','Next 30 days','UI label','Flag'],[(path(r['url']),r['count'],r['earliest'],r['latest'],r['past'],r['next_30_days'],r['button_text'],'; '.join(r['flags']) or 'none') for r in files],4700,cap)
    out+='\nMembership (subscription scope):\n\n'+table(['File','Membership','Scope / reason'],[
        (path(r['url']),(r.get('membership') or {}).get('status','not checked'),
         (r.get('membership') or {}).get('reason') or (r.get('membership') or {}).get('scope'))
        for r in files],2800,cap)
    differences=[dict(d,file=path(r['url']),page=path(r['source_page'])) for r in files for d in r.get('title_differences',[])]
    out+='\n'+bullets('Informational — title differs (same instant) ('+str(len(differences))+'):',differences,1200,cap,
        lambda d:cell(d['start'])+'; '+cell(d['economy'])+'; page “'+cell(d['page_title'],85)+'”; ICS “'+cell(d['file_title'],85)+'”; '+d['page']+' → '+d['file'])
    external=s['external']; checks=external['checks']; classes=Counter(r['classification'] for r in checks)
    out+='\n### Official links\n\n'+text(external['status'])+'.\n'
    out+='Totals by class: '+('; '.join(k+': '+str(v) for k,v in sorted(classes.items())) or 'no checked URLs')+'.\n\n'
    bad=[r for r in checks if r['classification']!='ok']
    out+=table(['Domain','URL','Status','Class','Page'],[(r.get('domain') or urlsplit(r['url']).hostname,r['url'],r['status'],r['classification'],', '.join(path(u) for u in r.get('source_pages',external.get('source_pages',{}).get(r['url'],[])))) for r in bad],4700)
    out+='\nOk official links — per-domain counts:\n\n'
    domains=Counter(r.get('domain') or urlsplit(r['url']).hostname for r in checks if r['classification']=='ok')
    out+=table(['Domain','Ok count'],sorted(domains.items()),2100)
    out+='\n'+text(external.get('policy',''),500)+'\n'
    return out


def sample_lines(receipt):
    raw=receipt.get('stdout','')
    try:
        value=json.loads(raw)
    except ValueError:
        return [text(line,160) for line in (raw or receipt.get('stderr','')).splitlines()]
    objects=value if isinstance(value,list) else [value]
    lines=['Observed JSON: '+str(len(objects))+' object(s).']
    for obj in objects:
        if not isinstance(obj,dict): lines.append(text(obj,150)); continue
        for key,val in obj.items():
            if isinstance(val,list): description=str(len(val))+' items'
            elif isinstance(val,dict): description='fields: '+', '.join(val)
            else: description=text(val,130)
            lines.append(key+': '+description)
    return lines


def section4(s,cap):
    out=text(s['isolation'],400)+'\n\n### Help tree\n\n'
    help_lines=[]
    help_share=3900//max(1,len(s['help']))
    for receipt in s['help']:
        heading='heronatlas '+' '.join(receipt['argv'])+'; exit '+str(receipt['exit_code'])
        help_lines.append(heading)
        help_lines+=lines_block(receipt.get('stdout','').splitlines(),max(100,help_share-size(heading)-8)).splitlines()
    out+=code_block(help_lines,4200)
    out+='\n### Command samples\n\nJSON samples below are rendered as fields and counts; raw stdout/stderr remain in JSON.\n\n'
    samples=s['samples']; share=7400//max(1,len(samples))
    for r in samples:
        lines=sample_lines(r)
        command='heronatlas '+' '.join(r['argv'])
        lead=short_bytes(command,130)+'; exit '+str(r['exit_code'])+'; '+short_bytes(text(lines[0] if lines else r.get('exception') or 'no output',100),80)+'\n\n'
        out+=lead+code_block(lines,max(80,share-size(lead)-8),cap=15)+'\n'
    out+='### Error probes\n\n'
    out+=table(['Case','Exit','stderr first line'],[(r['case'],r['exit_code'],(r.get('stderr','').splitlines() or ['(empty)'])[0]) for r in s['errors']],1700)
    return out


def markdown(data,max_items=8):
    cap=max(1,max_items)
    out=header(data)
    renderers={'1':section1,'2':section2,'3':section3,'4':section4}
    for number in ('1','2','3','4'):
        if number not in data['sections']: continue
        out+='## '+number+'. '+NAMES[number]+'\n\n<a id="section-'+number+'"></a>\n\n'
        out+=renderers[number](data['sections'][number],cap)+'\n'
    return out

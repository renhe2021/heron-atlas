"""Heron Atlas public-data CLI. Namespace conventions inspired by CLI-Anything."""
__version__ = '0.1.0'

"""Evidence-only product walkthrough. All I/O boundaries can be injected offline."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
import hashlib
import io
import json
import re
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit, urlunsplit, unquote, parse_qs
from urllib.request import Request, build_opener
from xml.etree import ElementTree
from zoneinfo import ZoneInfo

from . import __version__
from .client import base_url, NoRedirect, API_ROOT, CLOSED_LOOPBACK_BASE
from .browser import ChromeBrowser, find_chrome
from .snapshot_html import parse_html, summarize, home_rows, describe, trim

UTC=timezone.utc
ROUTES=['','central-banks','calendar','news','judgments','method','rules','corrections','sources']


@dataclass
class Response:
    url: str
    status: object
    body: bytes
    error: object = None

    def text(self): return self.body.decode('utf-8',errors='replace')
    def receipt(self): return {'status':self.status,'final_url':self.url,'error':self.error}


def fetch(url, method='GET', timeout=15, request_gate=None):
    original=url;seen=set()
    try:
        for _ in range(10):
            if url in seen: return Response(url,None,b'',error='Redirect cycle from '+original)
            seen.add(url)
            parts=urlsplit(url)
            if parts.scheme not in ('http','https') or parts.username is not None or parts.password is not None:
                return Response(url,None,b'',error='Unsupported or credential-bearing HTTP target')
            if request_gate: request_gate(url)
            request=Request(url,method=method,headers={'User-Agent':'HeronAtlasDiagnostic/'+__version__})
            try:
                with build_opener(NoRedirect).open(request,timeout=timeout) as r:
                    body=r.read(16*1024*1024+1) if method!='HEAD' else b''
                    if len(body)>16*1024*1024: return Response(r.geturl(),r.status,b'',error='Response exceeds 16 MiB; content not checked')
                    return Response(r.geturl(),r.status,body)
            except HTTPError as e:
                if e.code in (301,302,303,307,308) and e.headers.get('Location'):
                    url=urljoin(url,e.headers['Location']);e.close();continue
                return Response(e.geturl(),e.code,b'' if method=='HEAD' else e.read(1024*1024),str(e))
        return Response(url,None,b'',error='More than 10 redirects from '+original)
    except HTTPError as e:
        return Response(e.geturl(),e.code,b'' if method=='HEAD' else e.read(1024*1024),str(e))
    except (URLError,OSError,ValueError) as e:
        return Response(url,None,b'',str(e))


def classify(response, original=None):
    status=response.status
    if status is None: return 'network-error'
    if status in (403,429): return 'blocked-or-bot-filtered'
    if status>=500: return 'server-error'
    if status>=400: return 'client-error'
    if status>=300 or (original and response.url!=original): return 'redirect'
    return 'network-error' if response.error else 'ok'


def check_external(urls, fetcher, sleeper=time.sleep, clock=time.monotonic):
    """One worker per domain; shared host lock enforces start spacing including GET fallback."""
    locks={}; last={}; guard=threading.Lock()
    def gate(url):
        host=urlsplit(url).hostname
        with guard: lock=locks.setdefault(host,threading.Lock())
        with lock:
            wait=1-(clock()-last.get(host,float('-inf')))
            if wait>0: sleeper(wait)
            last[host]=clock()
    def request(url,method):
        try:
            if fetcher is fetch: return fetcher(url,method=method,timeout=15,request_gate=gate)
            gate(url)
            return fetcher(url,method=method,timeout=15)
        except Exception as e: return Response(url,None,b'',str(e))
    def check(url):
        response=request(url,'HEAD'); attempts=[dict(method='HEAD',**response.receipt())]
        if response.error or response.status is None or response.status>=400:
            response=request(url,'GET'); attempts.append(dict(method='GET',**response.receipt()))
        return dict(url=url,domain=urlsplit(url).hostname,classification=classify(response,url),attempts=attempts,**response.receipt())
    with ThreadPoolExecutor(max_workers=4) as pool: return list(pool.map(check,sorted(set(urls))))


def analyze_script(script):
    lines=script.splitlines()
    constants={}
    for name,quote,value in re.findall(r'\bconst\s+(\w+)\s*=\s*([\'"])(.*?)\2\s*;',script): constants[name]=value
    arrays={}
    for name,value in re.findall(r'\bconst\s+(\w+)\s*=\s*(\[[^\];]*\])\s*;',script):
        if re.fullmatch(r'\[\s*(?:[\'"][\w-]+[\'"]\s*,?\s*)*\]',value):
            arrays[name]=re.findall(r'[\'"]([\w-]+)[\'"]',value)
    operations=[]
    keys=[]; unresolved_keys=[]; referenced=set()
    for i,line in enumerate(lines,1):
        if re.search(r'localStorage\s*(?:\.|\[)',line):
            operations.append({'line':i,'code':line.strip()})
            for arg in re.findall(r'localStorage\.(?:getItem|setItem)\(\s*([^,)]+)',line):
                arg=arg.strip(); referenced.add(arg); value=constants.get(arg)
                if value is None and re.fullmatch(r'[\'"][^\'"]+[\'"]',arg): value=arg[1:-1]
                if value: keys.append(value)
                else: unresolved_keys.append(arg)
    # Only seed a contract supported by the fetched source. Do not pretend to
    # understand arbitrary JavaScript or fall back to a built-in storage key.
    defaults=[]
    for name,value in arrays.items():
        if re.search(r'(?:new Set\(\s*'+re.escape(name)+r'\s*\)|:\s*'+re.escape(name)+r'\s*[;},])',script):
            defaults.append((name,value))
    valid=(not unresolved_keys and len(set(keys))==1 and len(defaults)==1 and 'JSON.parse(' in script and
           'Array.isArray(' in script and re.search(r'localStorage\.setItem\([^\n]+JSON\.stringify\(\[\.\.\.',script))
    storage={'key':keys[0] if len(set(keys))==1 else None,'format':'JSON array of economy strings' if valid else None,
             'default':defaults[0][1] if len(defaults)==1 else None,
             'absent_behavior':'source default array; storage is absent' if valid else 'undetermined',
             'error':None if valid else 'Storage key, JSON array format or absent default could not be determined conservatively from fetched search.js'}
    selectors=list(dict.fromkeys(re.findall(r'(?:querySelectorAll|querySelector|closest)\(\s*[\'"]([^\'"\n]+)[\'"]\s*\)',script)))
    relevant=set()
    declarations=referenced|{name for name,_ in defaults}
    for i,line in enumerate(lines):
        if any(re.search(r'\bconst\s+'+re.escape(name)+r'\s*=',line) for name in declarations): relevant.add(i)
        if re.search(r'localStorage|\.hidden\b|(?:setAttribute|removeAttribute|toggleAttribute)\([^\n]*hidden|data-(?:home|follow|economy)|isFollowed|Date\.(?:now|parse)|data-(?:countdown|filter-date)|\b(?:now|stamp|age|at|left)\s*[<>=]',line):
            relevant.update(range(max(0,i-3),min(len(lines),i+4)))
    return {'storage':storage,'storage_operations':operations,'selectors':selectors,
            'code':[{'line':i+1,'code':lines[i]} for i in sorted(relevant)],
            'analysis_limit':'Literal selector and conservative storage-contract analysis; quoted source is evidence. Dynamic selectors/unsupported storage logic require manual review.'}


def parse_time(value):
    try:
        d=datetime.fromisoformat(value.replace('Z','+00:00'))
        return d.astimezone(UTC) if d.tzinfo is not None else None
    except (ValueError,TypeError,AttributeError): return None


def row_time(row):
    for attrs in row.get('times',[]):
        for key in ('data-countdown','datetime','data-time','data-at'):
            stamp=parse_time(attrs.get(key))
            if stamp: return stamp
    return None


def compute_flags(static, states, options, now):
    flags={'hidden_next_72h':[],'unsupported_economy':[],'never_revealed':[],'heading_count_mismatches':[], 'not_checked':[]}
    observed=[s for s in states if not s.get('error') and not s.get('errors')]
    for row in static:
        samples=[next((r for r in s.get('rows',[]) if r['selector']==row['selector']),None) for s in observed]
        complete=len(observed)==len(states) and bool(states) and all(r is not None for r in samples)
        hidden=complete and all(not r['visible'] for r in samples)
        receipt={k:row[k] for k in ('name','selector','economy','times')}
        if row['economy'] not in options: flags['unsupported_economy'].append(receipt)
        if hidden and row_time(row) and now<=row_time(row)<=now+timedelta(hours=72): flags['hidden_next_72h'].append(receipt)
        if hidden and row.get('static_hidden'): flags['never_revealed'].append(receipt)
        if not complete: flags['not_checked'].append(dict(receipt,reason='A browser state failed or row identity could not be matched in every state; universal-hidden assertion withheld'))
    for state in observed:
        for module in state.get('modules',[]):
            # Counts must be explicit count syntax, not arbitrary dates in titles.
            match=re.search(r'[（(]\s*(\d+)\s*(?:条|條|events?|rows?)?\s*[)）]|(?:共|total\s*:?|count\s*:)\s*(\d+)',module.get('heading',''),re.I)
            if match:
                count=int(next(x for x in match.groups() if x is not None))
                if count!=module['visible_rows']:
                    flags['heading_count_mismatches'].append({'state':state.get('state'),'module':module['selector'],
                        'heading':module['heading'],'heading_count':count,'visible_rows':module['visible_rows']})
    return flags


def parse_ics(text, now):
    unfolded=re.sub(r'\r?\n[ \t]','',text)
    events=[]; errors=[]; current=None
    for line in unfolded.splitlines():
        if line=='BEGIN:VEVENT': current={}
        elif line=='END:VEVENT':
            if current is not None: events.append(current)
            current=None
        elif current is not None and ':' in line:
            left,value=line.split(':',1); name=left.split(';')[0]
            current[name]=value
            if name=='DTSTART': current['DTSTART_PARAMS']=left
    if current is not None: errors.append('Unclosed VEVENT')
    if 'BEGIN:VCALENDAR' not in text: errors.append('Not a VCALENDAR file')
    instants=[]; dates=[]; past=upcoming=0
    for event in events:
        raw=event.get('DTSTART',''); params=event.get('DTSTART_PARAMS','')
        try:
            if re.fullmatch(r'\d{8}',raw):
                value=datetime.strptime(raw,'%Y%m%d').date(); dates.append(value.isoformat())
                past+=value<now.date(); upcoming+=now.date()<=value<=now.date()+timedelta(days=30)
                event['start']=value.isoformat(); event['date_only']=True
            else:
                value=datetime.strptime(raw.rstrip('Z'),'%Y%m%dT%H%M%S')
                tz=re.search(r';TZID=([^;:]+)',params)
                if raw.endswith('Z'): value=value.replace(tzinfo=UTC)
                elif tz: value=value.replace(tzinfo=ZoneInfo(tz[1])).astimezone(UTC)
                else: raise ValueError('floating DTSTART has no timezone')
                value=value.astimezone(UTC); instants.append(value.isoformat())
                past+=value<now; upcoming+=now<=value<=now+timedelta(days=30)
                event['start']=value.isoformat(); event['date_only']=False
        except (ValueError,KeyError) as e: errors.append('DTSTART '+raw+': '+str(e))
    starts=sorted(instants+dates)
    return {'count':len(events),'earliest':starts[0] if starts else None,'latest':starts[-1] if starts else None,
            'past':past,'next_30_days':upcoming,'unknown_start':len(errors), 'events':events,'errors':errors,
            'date_policy':'UTC instants; date-only values compared by UTC calendar day; floating times remain unknown'}


ECONOMIES={'us':r'美国|美國|\bUS\b|United States|\bFed\b', 'uk':r'英国|英國|\bUK\b|Bank of England',
           'ea':r'欧元区|歐元區|Euro area|\bECB\b', 'jp':r'日本|Japan|\bBOJ\b', 'cn':r'中国|中國|China|PBOC',
           'au':r'澳大利亚|澳大利亞|Australia|\bRBA\b','se':r'瑞典|Sweden|Riksbank',
           'ca':r'加拿大|Canada','ch':r'瑞士|Switzerland'}


def event_economy(event):
    if event.get('X-ECONOMY'): return event['X-ECONOMY'].lower()
    for code,pattern in ECONOMIES.items():
        if re.search(pattern,event.get('SUMMARY',''),re.I): return code
    return None


def calendar_comparison(parsed, context):
    """Match UID first, then UTC instant + economy when both expose it.

    Titles are evidence about presentation only. Ambiguous or missing identities
    withhold exact loss counts rather than inventing membership discrepancies.
    """
    expected=context.get('key_events')
    result={'status':'unknown','missing_in_file':None,'missing_in_page':None,
            'title_differences':[],'unknown_rows':list(context.get('unknown_rows',[])),
            'matched':[], 'page_only':[], 'file_only':[]}
    if expected is None:
        result['reason']='No identifiable static key-event calendar rows'
        return result
    # Explicit UID-only contexts are also accepted by diagnostic callers.
    rows=[{'uid':v,'start':None,'economy':None,'title':''} for v in sorted(expected)] if isinstance(expected,set) else expected
    events=[{'uid':e.get('UID'),'start':parse_time(e.get('start')),
             'economy':event_economy(e),'title':re.sub(r'\\([nN,;\\])',lambda m:'\n' if m[1] in 'nN' else m[1],e.get('SUMMARY',''))}
            for e in parsed['events']]
    unused=set(range(len(events)))
    # Reserve exact UID and explicit economy matches before weaker instant-only rows.
    for row in sorted(rows,key=lambda r:(not bool(r.get('uid')),not bool(r.get('economy')))):
        candidates=[]; stamp=parse_time(row.get('start'))
        if not row.get('uid') and stamp is None:
            result['unknown_rows'].append(dict(row,reason='No timezone-qualified <time datetime> on page row; identity unknown'))
            continue
        for i in sorted(unused):
            event=events[i]
            if row.get('uid'):
                matches=event['uid']==row['uid']
            else:
                matches=(event['start']==stamp and not (row.get('economy') and event['economy'] and row['economy']!=event['economy']))
            if matches: candidates.append(i)
        if len(candidates)>1:
            result['unknown_rows'].append(dict(row,reason='Multiple file events share the available identity; UID/economy needed'))
            continue
        if not candidates:
            result['page_only'].append(row)
            continue
        i=candidates[0]; unused.remove(i); event=events[i]
        result['matched'].append({'page':row,'file':parsed['events'][i], 'basis':'UID' if row.get('uid') else 'UTC instant and available economy'})
        normalize=lambda v:' '.join(v.split()).casefold()
        if stamp is not None and stamp==event['start'] and normalize(row.get('title',''))!=normalize(event['title']):
            result['title_differences'].append({'start':stamp.isoformat(),'economy':row.get('economy') or event['economy'],
                                                'page_title':row.get('title',''),'file_title':event['title']})
    for i in sorted(unused):
        event=events[i]
        if not event['uid'] and event['start'] is None:
            result['unknown_rows'].append(dict(event,reason='File event has neither UID nor UTC DTSTART; identity unknown'))
        else: result['file_only'].append(parsed['events'][i])
    if result['unknown_rows']:
        result['reason']='Unresolved identities; exact missing counts are unknown'
    else:
        result.update(missing_in_file=len(result['page_only']),missing_in_page=len(result['file_only']))
        result['status']='differs' if result['page_only'] or result['file_only'] else 'ok'
    return result


def subscription_comparison(parsed, context, url, label):
    """Check only the membership promised by this subscription, in its scope."""
    name=unquote(urlsplit(url).path).rsplit('/',1)[-1]
    economy=name[:-4] if name.endswith('.ics') and name[:-4] in ECONOMIES else None
    if name!='key-events.ics' and not re.search(r'关键事件|關鍵事件|key events',label,re.I):
        return {'status':'not_applicable','reason':'No key-event membership promise for this subscription',
                'missing_in_file':None,'missing_in_page':None,'title_differences':[],
                'unknown_rows':[],'matched':[],'page_only':[],'file_only':[]}
    scoped=dict(context)
    if economy and context.get('key_events') is not None:
        scoped['key_events']=[row for row in context['key_events'] if row.get('economy')==economy]
        scoped['unknown_rows']=list(context.get('unknown_rows',[]))+[
            dict(row,reason='Page row economy unavailable; subscription scope unknown')
            for row in context['key_events'] if not row.get('economy')]
    result=calendar_comparison(parsed,scoped)
    result['scope']=economy or 'all key events'
    return result


def calendar_mismatches(label, parsed, context, comparison=None):
    flags=[]
    numbers=re.findall(r'(\d+)\s*(?:events?|entries|条|條|项|項|个|個)',label,re.I)
    for n in numbers:
        if int(n)!=parsed['count']: flags.append('Label promises '+n+' events; file contains '+str(parsed['count']))
    # The button label is scoped to its own promise, not all adjacent economy links.
    wanted=[code for code,p in ECONOMIES.items() if re.search(p,label,re.I)]
    if len(wanted)==1:
        wrong=[e.get('SUMMARY',e.get('UID','?')) for e in parsed['events'] if event_economy(e) and event_economy(e)!=wanted[0]]
        if wrong: flags.append('Label economy '+wanted[0]+' differs from file event economy: '+', '.join(wrong))
        unknown=sum(event_economy(e) is None for e in parsed['events'])
        if unknown: flags.append('Economy promise not fully checkable: '+str(unknown)+' event economies undetermined')
    if comparison is not None or re.search(r'关键事件|關鍵事件|key events',label,re.I):
        comparison=comparison if comparison is not None else calendar_comparison(parsed,context)
        if comparison['status']=='unknown':
            reasons=sorted({r['reason'] for r in comparison['unknown_rows']})
            flags.append('Key-events membership counts unknown: '+str(len(comparison['unknown_rows']))+' unresolved identities; '+('; '.join(reasons) or comparison['reason']))
        elif comparison['status']=='differs':
            flags.append('Key-events membership differs: '+str(comparison['missing_in_file'])+' page rows absent from file; '+str(comparison['missing_in_page'])+' file rows absent from page')
    return flags


def calendar_context(doc, now=None):
    expected=[]; found=False
    for node in doc.select('[data-filter-item]'):
        level=node.attrs.get('data-filter-level','')
        if not re.search(r'关键|關鍵|key|^3$',level,re.I): continue
        found=True
        if re.search(r'published|released|已发布|已發布',node.attrs.get('data-filter-status',''),re.I): continue
        children=list(node.walk()); heads=[n for n in children if re.fullmatch('h[1-6]',n.tag)]
        links=[n for n in children if n.tag=='a']
        title=(heads or links)[0].text() if heads or links else ''
        times=[n.attrs['datetime'] for n in children if n.tag=='time' and 'datetime' in n.attrs]
        stamp=next((parse_time(t) for t in times if parse_time(t)),None)
        if now and stamp and stamp<now: continue
        # A day filter is not a datetime. Date-only/invalid rows stay unknown.
        if now and not stamp and node.attrs.get('data-filter-date','9999')<now.date().isoformat(): continue
        economy=node.attrs.get('data-economy') or node.attrs.get('data-filter-economy')
        expected.append({'uid':node.attrs.get('data-event-uid') or node.attrs.get('data-uid'),
                         'start':stamp.isoformat() if stamp else None,'economy':economy,'title':title})
    return {'key_events':expected if found else None,
            'basis':'Unpublished key-level rows: explicit UID, otherwise UTC <time datetime> and economy where both expose it; titles informational; past rows excluded',
            'unknown_rows':[]}


def cli_self_test(base, site, fetcher, injected=True):
    """Invoke Click in-process, using the real reader; injected HTTP only for offline fixtures."""
    from click.testing import CliRunner
    from unittest.mock import patch
    from contextlib import ExitStack
    from .cli import main
    from . import client as client_module
    import inspect
    result={'isolation':'in-process Click CliRunner; '+('injected fetcher at urllib opener boundary (offline fixture)' if injected else 'default urllib client transport')+'; no shell or installed-script substitution', 'help':[], 'samples':[], 'errors':[], 'schema':{}}
    runner=CliRunner(**({'mix_stderr':False} if 'mix_stderr' in inspect.signature(CliRunner).parameters else {}))
    class Opener:
        def open(self,req,timeout):
            r=fetcher(req.full_url,timeout=timeout)
            if r.status is None: raise URLError(r.error or 'No HTTP response')
            if not 200<=r.status<300 or r.url!=req.full_url: raise HTTPError(req.full_url,r.status,'diagnostic fetch',{},None)
            return io.BytesIO(r.body)
    def invoke(args):
        value=runner.invoke(main,args)
        return {'argv':args,'exit_code':value.exit_code,'stdout':value.stdout,
                'stderr':value.stderr,'exception':str(value.exception) if value.exception and not isinstance(value.exception,SystemExit) else None}
    def sample(command,args):
        for fmt in ([],['--json']):
            receipt=invoke(['--base-url',base,command,*args,*fmt]);result['samples'].append(receipt)
            if fmt and receipt['exit_code']==0:
                try:
                    data=json.loads(receipt['stdout']); objects=data if isinstance(data,list) else [data]
                    properties={}
                    for obj in objects:
                        if isinstance(obj,dict):
                            for k,v in obj.items(): properties.setdefault(k,set()).add(type(v).__name__)
                    result['schema'][command]={'type':'array' if isinstance(data,list) else type(data).__name__,
                        'properties':{k:sorted(v) for k,v in properties.items()},
                        'note':'Observed output only; empty arrays cannot establish item keys' if not objects else 'Observed top-level keys; not a formal complete schema'}
                    return_data[command]=data
                except ValueError: result['schema'][command]={'error':'Successful --json run did not emit JSON'}
    # Use one injectable opener for the exact Client path, including its schema
    # and HTTP error handling. It still fetches real URLs in a real snapshot run.
    return_data={}
    with ExitStack() as stack:
        if injected:
            stack.enter_context(patch.object(client_module,'build_opener',lambda *a:Opener()))
            stack.enter_context(patch(__name__+'.fetch',fetcher))
        result['help'].append(invoke(['--help']))
        for name in sorted(main.commands): result['help'].append(invoke([name,'--help']))
        for name in ('info','banks','events','judgments','calendar'): sample(name,[])
        index=return_data.get('info',{});banks=return_data.get('banks',[])
        statement_paths=[e.get('path','') for e in index.get('endpoints',[]) if (API_ROOT+'statements/') in e.get('path','')] if isinstance(index,dict) else []
        bank=statement_paths[0].rsplit('/',1)[-1].removesuffix('.json') if statement_paths else (banks[0]['id'] if banks else 'fed')
        if not statement_paths: result.setdefault('selection_notes',[]).append('Statement bank chosen as a probe; no statement endpoint discovered')
        sample('statements',[bank]); sample('statement',[bank])
        for name,plural,key,fallback in [('event','events','slug','diagnostic-unknown'),('judgment','judgments','id','J-diagnostic-unknown')]:
            rows=return_data.get(plural,[])
            arg=str(rows[0][key]) if isinstance(rows,list) and rows and key in rows[0] else fallback
            sample(name,[arg])
        sample('cite',['/'])
        # Include the diagnostic command itself without recursion into section 4.
        for fmt in ('markdown','json'):
            receipt=invoke(['debug-snapshot','--site-url',site,'--cli-base-url',base,
                     '--sections','1','--no-external','--max-items','1','--format',fmt])
            result['samples'].append(receipt)
            if fmt=='json' and receipt['exit_code']==0:
                observed=json.loads(receipt['stdout'])
                result['schema']['debug-snapshot']={'type':'dict','properties':{k:[type(v).__name__] for k,v in observed.items()},'note':'Observed diagnostic JSON keys'}
        errors=[('unknown bank',['statement','diagnostic-unknown']),('unknown judgment id',['judgment','J-diagnostic-unknown']),
                ('unknown event slug',['event','diagnostic-unknown']),('bad date',['statement',bank,'--date','bad-date']),
                ('non-https base URL',['--base-url','http://example.invalid','info']),
                ('unreachable base',['--base-url',CLOSED_LOOPBACK_BASE,'info']),
                ('site base without api/v1 (probe; outcome observed, not assumed)',['--base-url',site,'info'])]
        for label,args in errors:
            if '--base-url' not in args: args=['--base-url',base,*args]
            result['errors'].append(dict(case=label,**invoke(args)))
    return result


def collect(site_url, cli_base_url=None, sections=(1,2,3,4), max_items=8, no_external=False,
            chrome=None, fetcher=None, browser=None, now=None):
    site=base_url(site_url); cli_base=base_url(cli_base_url or site_url)
    injected=fetcher is not None
    fetcher=fetcher or fetch; now=now or datetime.now(UTC)
    data={'header':{'run_at_utc':now.astimezone(UTC).isoformat(),'site_url':site,'cli_base_url':cli_base,
                    'cli_version':__version__,'built_at':None,'homepage_sha256':None,'search_js_sha256':None},
          'sections':{},'errors':[]}
    cache={}; documents={}
    def get(url):
        if url not in cache:
            try: cache[url]=fetcher(url,timeout=15)
            except Exception as e: cache[url]=Response(url,None,b'',str(e))
        return cache[url]
    def document(url):
        r=get(url)
        if url not in documents: documents[url]=parse_html(r.text())
        return documents[url]
    home=get(site); script=get(urljoin(site,'search.js')); manifest=get(urljoin(site,'manifest.json'))
    for name,r in [('homepage',home),('search_js',script)]:
        if r.status and 200<=r.status<300 and not r.error: data['header'][name+'_sha256']=hashlib.sha256(r.body).hexdigest()
        elif (name=='homepage' and any(n in sections for n in (1,2,3))) or (name=='search_js' and 2 in sections):
            data['errors'].append(name+': HTTP '+str(r.status)+' '+str(r.error or ''))
    data['header']['manifest']=manifest.receipt()
    try:
        if manifest.status!=200: raise ValueError('HTTP '+str(manifest.status)+' '+str(manifest.error))
        built_at=json.loads(manifest.body)['built_at']
        if not isinstance(built_at,str) or not parse_time(built_at): raise ValueError('Invalid built_at timestamp')
        data['header']['built_at']=built_at
    except (ValueError,KeyError,TypeError) as e: data['header']['build_stamp_error']=str(e)
    sitemap=get(urljoin(site,'sitemap.xml')); urls=[]
    try:
        if sitemap.status!=200: raise ValueError('HTTP '+str(sitemap.status)+' '+str(sitemap.error))
        xml=ElementTree.fromstring(sitemap.body)
        for node in xml.iter():
            if node.tag.rsplit('}',1)[-1]=='loc' and node.text:
                url=urljoin(site,node.text.strip())
                if urlsplit(url).netloc==urlsplit(site).netloc and urlsplit(url).scheme in ('https','http'): urls.append(url)
                else: data.setdefault('scope_findings',[]).append('Sitemap URL outside selected site not crawled: '+url)
    except (ValueError,ElementTree.ParseError) as e:
        if any(n in sections for n in (1,3)): data['errors'].append('sitemap.xml unavailable: '+str(e))
    # A content timestamp is a labelled fallback, never a fabricated build stamp.
    feed=get(urljoin(site,'feed.xml')); candidates=[]; timestamp_sources=[]
    for source,r,tag in [('feed.xml <lastBuildDate>',feed,'lastBuildDate'),('sitemap.xml <lastmod>',sitemap,'lastmod')]:
        stamps=[]; error=None
        try:
            if r.status!=200: raise ValueError('HTTP '+str(r.status))
            for node in ElementTree.fromstring(r.body).iter():
                if node.tag.rsplit('}',1)[-1]!=tag or not node.text: continue
                stamp=parse_time(node.text.strip())
                if stamp is None and tag=='lastmod' and re.fullmatch(r'\d{4}-\d{2}-\d{2}',node.text.strip()):
                    stamp=datetime.fromisoformat(node.text.strip()).replace(tzinfo=UTC)
                if stamp is None and tag=='lastBuildDate':
                    try: stamp=parsedate_to_datetime(node.text.strip())
                    except (ValueError,TypeError,OverflowError): pass
                if stamp and stamp.tzinfo is not None: stamps.append(stamp.astimezone(UTC))
            if not stamps: error='No parseable timezone-qualified timestamp'
        except (ValueError,ElementTree.ParseError) as e: error=str(e)
        timestamp_sources.append(dict(source=source,**r.receipt(),newest=max(stamps).isoformat() if stamps else None,timestamp_error=error))
        if stamps: candidates.append((max(stamps),source))
    data['header']['timestamp_sources']=timestamp_sources
    newest=max(candidates) if candidates else None
    data['header']['content_timestamp']={'value':newest[0].isoformat(),'source':newest[1]} if newest else None
    full=[urljoin(site,path) for path in ('','zh-hant/','en/')]
    full += [urljoin(site,route+'/') for route in ROUTES[1:]]
    full += [urljoin(site,prefix+route+'/') for prefix in ('zh-hant/','en/') for route in ROUTES[1:]]
    if 1 in sections or 3 in sections:
        for url in dict.fromkeys(full+urls): document(url)
    if 1 in sections:
        pages=[]
        for url in full:
            pages.append(dict(url=url,**get(url).receipt(),**summarize(document(url))))
        other=[]; counts={}; inventory={}
        for url in dict.fromkeys(urls):
            path=urlsplit(url).path[len(urlsplit(site).path):].strip('/').split('/')
            top=path[0] if path and path[0] else '/';counts[top]=counts.get(top,0)+1
            inv=inventory.setdefault(top,{'count':0,'non_200':0}); inv['count']+=1; inv['non_200']+=get(url).status!=200
            if url not in full:
                summary=summarize(document(url)); other.append(dict(url=url,title=summary['title'],h1=[h['text'] for h in summary['headings'] if h['level']==1],**get(url).receipt()))
        data['sections']['1']={'scope':'Static HTML as crawlers/no-JS readers see it. Visible text excludes hidden-attribute ancestors, head, script, style and template; CSS visibility is measured only in section 2.',
                               'pages':pages,'other_sitemap_urls':other,'counts_per_top_level_path':counts,
                               'sitemap_inventory':inventory,'sitemap_urls':list(dict.fromkeys(urls)),'sitemap':sitemap.receipt()}
    if 2 in sections:
        analysis=analyze_script(script.text()); result={'analysis':analysis,'pages':[],'subresource_findings':[]}
        resource_index={}
        owned=browser is None
        startup_error=None
        if browser is None:
            try:
                if analysis['storage']['error']: raise RuntimeError('Storage contract unavailable: '+analysis['storage']['error'])
                browser=ChromeBrowser(find_chrome(chrome))
            except Exception as e: startup_error=str(e);data['errors'].append(startup_error)
        try:
            for path in ('','en/'):
                url=urljoin(site,path);doc=document(url);static=home_rows(doc)
                static_follows=[dict(describe(n),name=n.text(),economy=n.attrs['data-follow-economy'],static_hidden=n.hidden()) for n in doc.walk() if 'data-follow-economy' in n.attrs]
                options=list(dict.fromkeys(n.attrs['data-follow-economy'] for n in doc.walk() if 'data-follow-economy' in n.attrs))
                matches=[]
                for selector in analysis['selectors']:
                    matches.append({'selector':selector,'elements':[describe(n) for n in doc.select(selector)],
                                    'note':'Literal static selector matching; complex combinators are not interpreted' if re.search(r'[ >+~:]',selector) else None})
                states=[]
                for name,storage in [('first-time',None),('us',['us']),('uk',['uk']),('all',options)]:
                    try:
                        if startup_error: raise RuntimeError(startup_error)
                        if get(url).status!=200: raise RuntimeError('Homepage not HTTP 200: '+str(get(url).status))
                        capture=browser.capture(url,storage,analysis);capture.update(state=name,seed=storage)
                        for row in capture.get('rows',[])+capture.get('follow_rows',[]):
                            original=next((r for r in static+static_follows if r['selector']==row['selector']),None)
                            row['static_attributes']=original['attributes'] if original else None
                            row['attribute_diff']={k:{'static':(original or {}).get('attributes',{}).get(k),'post_js':row.get('attributes',{}).get(k)}
                                for k in set((original or {}).get('attributes',{}))|set(row.get('attributes',{}))
                                if (original or {}).get('attributes',{}).get(k)!=row.get('attributes',{}).get(k) or
                                (k=='hidden' and ('hidden' in (original or {}).get('attributes',{}))!=('hidden' in row.get('attributes',{})))}
                            row['decision']=('Observed hidden-attribute writes; stack identifies executed path' if row.get('mutations') else 'No hidden-attribute write observed; computed visibility reported; cause undetermined')
                        states.append(capture)
                        for failure in capture.get('subresource_failures',[]):
                            key=(failure['url'],failure['resource_type'],failure['reason'])
                            finding=resource_index.setdefault(key,{k:failure[k] for k in ('url','resource_type','reason','status','fatal')})
                            state_ref=url+' '+name
                            if state_ref not in finding.setdefault('states',[]): finding['states'].append(state_ref)
                        if capture.get('errors'):
                            details=[]
                            for error in capture['errors']:
                                details.append(str(error.get('error',error.get('method','Browser state failed')))+' '+str(error.get('url','')) if isinstance(error,dict) else str(error))
                            data['errors'].append(url+' state '+name+': '+'; '.join(details))
                    except Exception as e:
                        states.append({'state':name,'seed':storage,'error':str(e)})
                        if not startup_error: data['errors'].append(url+' state '+name+': '+str(e))
                result['pages'].append({'url':url,'follow_options':options,'selector_matches':matches,'static_rows':static,'static_follow_rows':static_follows,
                    'states':states,'flags':compute_flags(static,states,options,now)})
        finally:
            if owned and browser: browser.close()
        result['startup_error']=startup_error
        result['subresource_findings']=list(resource_index.values())
        result['scope']='Real current browser clock; fresh isolated page per state, storage seeded before site scripts. Attribute diffs and instrumented mutation stacks are observations; no write means code-path cause is unknown.'
        data['sections']['2']=result
    if 3 in sections:
        anchors=[]; calendars=[]; external=[]; external_pages={}
        for url,doc in list(documents.items()):
            for node in doc.walk():
                href=node.attrs.get('href')
                if node.tag!='a' or not href: continue
                target=urljoin(get(url).url,href); parts=urlsplit(target)
                if parts.fragment.startswith('J-'):
                    dest=urlunsplit((parts.scheme,parts.netloc,parts.path,parts.query,''))
                    if parts.netloc!=urlsplit(site).netloc:
                        anchors.append({'source_page':url,'url':target,'status':'not-checked','reason':'Cross-origin judgment target'})
                    else:
                        ids={n.attrs['id'] for n in document(dest).walk() if 'id' in n.attrs}
                        ok=get(dest).status==200 and unquote(parts.fragment) in ids
                        anchors.append({'source_page':url,'url':target,'status':'ok' if ok else 'broken','target_http':get(dest).status,'anchor':unquote(parts.fragment)})
                path=urlsplit(url).path
                if re.search(r'/(?:central-banks|statements|events|judgments)(?:/|$)',path) and parts.scheme in ('http','https') and parts.netloc!=urlsplit(site).netloc:
                    external.append(target)
                    if url not in external_pages.setdefault(target,[]): external_pages[target].append(url)
                if not path.rstrip('/').endswith('/calendar'): continue
                ics_targets=[]
                if parts.path.endswith('.ics'):
                    ics_targets.append(urlunsplit(('https' if parts.scheme=='webcal' else parts.scheme,parts.netloc,parts.path,parts.query,'')))
                for values in parse_qs(parts.query).values():
                    for value in values:
                        nested=urlsplit(value)
                        if nested.path.endswith('.ics') and nested.scheme in ('https','http','webcal'):
                            ics_targets.append(urlunsplit(('https' if nested.scheme=='webcal' else nested.scheme,nested.netloc,nested.path,nested.query,'')))
                for target_ics in dict.fromkeys(ics_targets):
                    r=get(target_ics);parsed=parse_ics(r.text(),now)
                    parent=node.parent
                    nearby=trim(parent.text() if parent else node.text(),640)
                    context=calendar_context(doc,now)
                    label=node.text()
                    # Neighbouring links may promise a different economy/feed.
                    # The key-events filename covers generic Apple/Google labels.
                    comparison=subscription_comparison(parsed,context,target_ics,label) if r.status==200 else None
                    calendars.append({'source_page':url,'url':target_ics,'button_text':label,'nearby_text':nearby,
                        **r.receipt(),**parsed,'comparison_basis':context.get('basis'),
                        'membership':comparison,'title_differences':comparison['title_differences'] if comparison else [],
                        'flags':calendar_mismatches(label,parsed,context,comparison) if r.status==200 else ['File not checked: '+str(r.error or r.status)]})
        checks=check_external(external,fetcher) if not no_external else []
        for check in checks: check['source_pages']=external_pages[check['url']]
        grouped={}
        for url in sorted(set(external)): grouped.setdefault(urlsplit(url).hostname,[]).append(url)
        data['sections']['3']={'judgment_links':anchors,'calendar_files':calendars,
            'external':{'status':'skipped (--no-external)' if no_external else 'checked', 'domains':grouped,'checks':checks,'source_pages':external_pages,
                        'policy':'Unique URL once; HEAD with GET fallback on failure; plain UA; 15 s timeout; at most 4 workers; >=1 s same-host request spacing. Status is reachability evidence, not authority verification.'}}
    if 4 in sections: data['sections']['4']=cli_self_test(cli_base,site,fetcher,injected=injected)
    return data


def markdown(data, max_items=8):
    from .snapshot_markdown import markdown as readable_markdown
    return readable_markdown(data,max_items)


def render(data, format='markdown', max_items=8):
    return json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n' if format=='json' else markdown(data,max_items)
